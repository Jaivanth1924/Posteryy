POSTERYY — 8 NEW ANIME POSTERS

1. Upload all JPG files from images/ into your GitHub repository's images/ folder.
2. Open index.html and find the existing <div class="grid">.
3. Paste anime-cards-snippet.html inside that grid, after the existing cards.
4. Commit to main, then refresh https://jaivanth1924.github.io/Posteryy/

All 8 cards use the Anime category, A4 size, high-quality glossy photo paper, and ₹50 price.
